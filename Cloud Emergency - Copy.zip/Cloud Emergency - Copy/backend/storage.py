# This file acts as an in-memory database

users = []
emergencies = []
