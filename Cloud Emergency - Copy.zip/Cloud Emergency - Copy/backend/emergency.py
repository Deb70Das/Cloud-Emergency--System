from flask import Blueprint, request, jsonify
from datetime import datetime
import uuid
from storage import emergencies

emergency = Blueprint("emergency", __name__)

# Report Emergency
@emergency.route("/report-emergency", methods=["POST"])
def report_emergency():
    data = request.json

    emergency_data = {
        "id": str(uuid.uuid4()),
        "type": data["type"],
        "location": data["location"],
        "description": data["description"],
        "priority": data.get("priority", "Medium"),
        "status": "Pending",
        "timestamp": datetime.utcnow().isoformat()
    }

    emergencies.append(emergency_data)

    print("🚨 ALERT SENT FOR:", emergency_data["type"])

    return jsonify({
        "message": "Emergency reported successfully",
        "data": emergency_data
    }), 201


# Filter Emergencies
@emergency.route("/filter-emergencies", methods=["GET"])
def filter_emergencies():
    e_type = request.args.get("type")
    status = request.args.get("status")
    location = request.args.get("location")

    results = emergencies

    if e_type:
        results = [e for e in results if e["type"] == e_type]
    if status:
        results = [e for e in results if e["status"] == status]
    if location:
        results = [e for e in results if e["location"] == location]

    return jsonify(results), 200


# Update Emergency Status
@emergency.route("/update-status", methods=["PUT"])
def update_status():
    data = request.json

    for e in emergencies:
        if e["id"] == data["id"]:
            e["status"] = data["status"]
            return jsonify({"message": "Status updated successfully"})

    return jsonify({"error": "Emergency not found"}), 404
