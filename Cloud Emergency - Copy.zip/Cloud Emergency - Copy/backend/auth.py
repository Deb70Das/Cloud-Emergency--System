from flask import Blueprint, request, jsonify
import uuid
from storage import users

auth = Blueprint("auth", __name__)

@auth.route("/register", methods=["POST"])
def register():
    data = request.json

    user = {
        "id": str(uuid.uuid4()),
        "name": data["name"],
        "email": data["email"],
        "password": data["password"],
        "role": "user"
    }

    users.append(user)
    return jsonify({"message": "User registered successfully"}), 201


@auth.route("/login", methods=["POST"])
def login():
    data = request.json

    for user in users:
        if user["email"] == data["email"] and user["password"] == data["password"]:
            token = str(uuid.uuid4())
            user["token"] = token
            return jsonify({
                "message": "Login successful",
                "token": token,
                "role": user["role"]
            })

    return jsonify({"error": "Invalid credentials"}), 401
