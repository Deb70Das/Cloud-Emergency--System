from flask import Flask
from flask_cors import CORS
from auth import auth
from emergency import emergency

app = Flask(__name__)
CORS(app)

app.register_blueprint(auth)
app.register_blueprint(emergency)

@app.route("/")
def home():
    return "Cloud-Based Emergency Portal Backend Running"

if __name__ == "__main__":
    app.run(debug=True)
