async function applyFilter() {
    const type = document.getElementById("type").value;
    const status = document.getElementById("status").value;
    const city = document.getElementById("city").value;

    let query = "?";

    if (type) query += `type=${type}&`;
    if (status) query += `status=${status}&`;
    if (city) query += `city=${city}&`;

    const data = await getEmergencies(query);
    displayData(data);
}