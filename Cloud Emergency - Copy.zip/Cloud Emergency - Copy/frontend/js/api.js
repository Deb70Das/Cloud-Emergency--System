// ================= GET ALL EMERGENCIES =================
async function getEmergencies(query = "") {
    try {
        const response = await fetch(`${BASE_URL}/emergencies${query}`);
        return await response.json();
    } catch (error) {
        console.error("Error fetching emergencies:", error);
        return [];
    }
}

// ================= REPORT EMERGENCY =================
async function submitEmergency(data) {
    try {
        const response = await fetch(`${BASE_URL}/report`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        return await response.json();
    } catch (error) {
        console.error("Error reporting emergency:", error);
    }
}

// ================= LOGIN =================
async function loginUser(data) {
    try {
        const response = await fetch(`${BASE_URL}/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        return await response.json();
    } catch (error) {
        console.error("Login error:", error);
    }
}