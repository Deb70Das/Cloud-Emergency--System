async function loadData() {
    const data = await getEmergencies();
    displayData(data);
}

function displayData(data) {
    const container = document.getElementById("emergencyList");
    container.innerHTML = "";

    if (data.length === 0) {
        container.innerHTML = "<p>No emergencies found.</p>";
        return;
    }

    data.forEach(item => {
        let statusClass = "";

        if (item.status === "Pending") statusClass = "pending";
        if (item.status === "In-Progress") statusClass = "inprogress";
        if (item.status === "Resolved") statusClass = "resolved";

        container.innerHTML += `
            <div class="card">
                <h3>${item.emergency_type}</h3>
                <p><strong>City:</strong> ${item.city}</p>
                <p><strong>Status:</strong> <span class="${statusClass}">${item.status}</span></p>
                <p><strong>Time:</strong> ${new Date(item.timestamp).toLocaleString()}</p>
            </div>
        `;
    });
}

// Auto refresh every 15 seconds
setInterval(loadData, 15000);

window.onload = loadData;