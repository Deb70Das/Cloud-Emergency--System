const reportForm = document.getElementById("reportForm");

if (reportForm) {
    reportForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const emergency_type = document.getElementById("emergency_type").value;
        const city = document.getElementById("city").value;
        const description = document.getElementById("description").value;

        const data = {
            emergency_type,
            city,
            description,
            timestamp: new Date()
        };

        const result = await submitEmergency(data);

        if (result) {
            document.getElementById("message").innerText = "Emergency Reported Successfully!";
            reportForm.reset();
        } else {
            document.getElementById("message").innerText = "Error submitting report!";
        }
    });
}