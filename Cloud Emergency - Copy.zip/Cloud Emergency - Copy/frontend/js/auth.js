const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const result = await loginUser({ email, password });

        if (result && result.token) {
            localStorage.setItem("token", result.token);
            window.location.href = "dashboard.html";
        } else {
            document.getElementById("errorMsg").innerText = "Invalid credentials!";
        }
    });
}

// Logout
function logout() {
    localStorage.removeItem("token");
    window.location.href = "login.html";
}