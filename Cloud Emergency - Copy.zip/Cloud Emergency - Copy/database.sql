-- ============================================
-- REAL-TIME CLOUD EMERGENCY DATABASE
-- (NO SAMPLE DATA - DATA WILL COME FROM USER)
-- ============================================

CREATE DATABASE IF NOT EXISTS emergency_portal;
USE emergency_portal;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS Logs;
DROP TABLE IF EXISTS Alerts;
DROP TABLE IF EXISTS Emergencies;
DROP TABLE IF EXISTS Admin_Staff;
DROP TABLE IF EXISTS Users;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- USERS TABLE (Login System)
-- ============================================

CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password VARCHAR(255) NOT NULL,
    role ENUM('citizen','admin') DEFAULT 'citizen',
    region VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- ADMIN STAFF TABLE
-- ============================================

CREATE TABLE Admin_Staff (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    assigned_region VARCHAR(100),
    phone VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- EMERGENCIES TABLE (REAL-TIME DATA COLLECTION)
-- ============================================

CREATE TABLE Emergencies (
    emergency_id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('Medical','Fire','Police') NOT NULL,
    description TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    latitude DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    priority ENUM('Low','Moderate','High') NOT NULL,
    status ENUM('Pending','In-Progress','Resolved') DEFAULT 'Pending',
    reported_by INT NOT NULL,
    source ENUM('Internet','Satellite') DEFAULT 'Internet',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (reported_by) REFERENCES Users(user_id)
);

-- ============================================
-- ALERTS TABLE
-- ============================================

CREATE TABLE Alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    disaster_type VARCHAR(50),
    region VARCHAR(100),
    message TEXT,
    severity ENUM('Low','Moderate','High'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- LOGS TABLE (AUTOMATIC TRACKING)
-- ============================================

CREATE TABLE Logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    action VARCHAR(100),
    emergency_id INT,
    performed_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (emergency_id) REFERENCES Emergencies(emergency_id),
    FOREIGN KEY (performed_by) REFERENCES Users(user_id)
);

-- ============================================
-- PERFORMANCE INDEXES FOR REAL-TIME FILTERING
-- ============================================

CREATE INDEX idx_status ON Emergencies(status);
CREATE INDEX idx_city ON Emergencies(city);
CREATE INDEX idx_priority ON Emergencies(priority);
CREATE INDEX idx_created_at ON Emergencies(created_at);
-- ============================================
-- VERIFY REAL-TIME CLOUD EMERGENCY DATABASE
-- ============================================

-- 1️⃣ Check if database exists
SHOW DATABASES;

-- 2️⃣ Select your database
USE emergency_portal;

-- 3️⃣ Check all tables created
SHOW TABLES;

-- 4️⃣ Check structure of each table

DESCRIBE Users;
DESCRIBE Admin_Staff;
DESCRIBE Emergencies;
DESCRIBE Alerts;
DESCRIBE Logs;

-- 5️⃣ See full CREATE TABLE query (exact structure stored in MySQL)

SHOW CREATE TABLE Users;
SHOW CREATE TABLE Admin_Staff;
SHOW CREATE TABLE Emergencies;
SHOW CREATE TABLE Alerts;
SHOW CREATE TABLE Logs;

-- 6️⃣ Check if tables are empty (they should be empty now)

SELECT * FROM Users;
SELECT * FROM Admin_Staff;
SELECT * FROM Emergencies;
SELECT * FROM Alerts;
SELECT * FROM Logs;

-- 7️⃣ Check indexes (performance verification)

SHOW INDEX FROM Emergencies;